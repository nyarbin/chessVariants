#ifndef PROLOGUTILS_H
#define PROLOGUTILS_H

/*
 *  Built on :
 *  STerm.h and SState.h
 *  GGP
 *
 *  Created by Yngvi Bjornsson on 3/18/07.
 *  Copyright 2007 CADIA Reykjavík University. All rights reserved.
 *
 */
#include "utils/sterm.h"
#include "utils/smove.h"
#include "utils/sstate.h"

#endif // PROLOGUTILS_H
